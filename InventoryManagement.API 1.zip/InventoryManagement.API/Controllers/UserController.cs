﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using InventoryManagement.API.Data;
using InventoryManagement.API.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore; // ✅ Required for EF Core async methods

namespace InventoryManagement.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly InventoryDbContext _context;

        public UserController(InventoryDbContext context)
        {
            _context = context;
        }

        // ✅ GET: api/user
        [HttpGet]
        public async Task<ActionResult<IEnumerable<User>>> GetUsers()
        {
            var users = await _context.Users
                .Where(u => u.IsActive)
                .ToListAsync();

            return Ok(users);
        }

        // ✅ POST: api/user/login
        [HttpPost("login")]
        public async Task<ActionResult<User>> Login([FromBody] LoginRequest request)
        {
            if (request == null || string.IsNullOrEmpty(request.Email))
            {
                return BadRequest("Invalid login request.");
            }

            var user = await _context.Users
                .FirstOrDefaultAsync(u => u.Email == request.Email && u.IsActive);

            if (user == null)
            {
                // Create a new user if not found
                user = new User
                {
                    UserName = request.Name ?? "New User",
                    Email = request.Email,
                    UserType = request.Role ?? "User",
                    IsActive = true,
                    CreatedDate = DateTime.UtcNow
                };

                _context.Users.Add(user);
                await _context.SaveChangesAsync();
            }

            return Ok(user);
        }
    }

    // ✅ DTO for login request
    public class LoginRequest
    {
        public string? Name { get; set; }
        public string Email { get; set; } = string.Empty;
        public string? Role { get; set; }
    }
}
