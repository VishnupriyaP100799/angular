﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace InventoryManagement.API.Models
{
    public class Inventory
    {
        [Key]
        public int InventoryID { get; set; }

        [Required]
        [StringLength(100)]
        public string ItemName { get; set; }

        [Required]
        public int StockQty { get; set; }

        [Required]
        public int ReorderQty { get; set; }

        [Required]
        public int PriorityStatus { get; set; } // 0 = Low, 1 = High

        public DateTime CreatedDate { get; set; } = DateTime.Now;
        public DateTime? LastUpdated { get; set; }

        // Navigation property
        public virtual ICollection<Stock> Stocks { get; set; } = new List<Stock>();
    }

    public class User
    {
        [Key]
        public int UserID { get; set; }

        [Required]
        [StringLength(100)]
        public string UserName { get; set; }

        [Required]
        [EmailAddress]
        [StringLength(150)]
        public string Email { get; set; }

        [Required]
        public string UserType { get; set; } // Admin, User, Supplier

        public DateTime CreatedDate { get; set; } = DateTime.Now;
        public bool IsActive { get; set; } = true;
    }

    public class Stock
    {
        [Key]
        public int StockID { get; set; }

        [Required]
        public int InventoryID { get; set; }

        [ForeignKey("InventoryID")]
        public virtual Inventory Inventory { get; set; }

        [Required]
        public int Quantity { get; set; }

        [Required]
        public string TransactionType { get; set; } // IN, OUT, ADJUSTMENT

        public string Remarks { get; set; }

        public int UserID { get; set; } // Who performed the transaction

        public DateTime TransactionDate { get; set; } = DateTime.Now;
    }
}
